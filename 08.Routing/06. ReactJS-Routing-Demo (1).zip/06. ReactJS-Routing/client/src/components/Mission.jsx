export default function Mission() {
    return (
        <>
            <h1>Our Mission</h1>
            
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim, eaque delectus. Ratione, nobis? Magni, earum nobis. Corporis iusto beatae obcaecati dignissimos ipsam quia harum sequi, illum repudiandae perferendis rem laborum!</p>
        </>
    );
}

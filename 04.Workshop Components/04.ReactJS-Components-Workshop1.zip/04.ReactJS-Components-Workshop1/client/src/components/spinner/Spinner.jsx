export default function Spinner() {
    return (
        <div className="loading-shade">
            <div className="spinner"></div>
        </div>
    );
}
